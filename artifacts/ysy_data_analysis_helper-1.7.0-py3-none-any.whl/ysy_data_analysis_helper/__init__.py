"""
ysy_data_analysis_helper
Top-level public API:
- Core: plot, temp_style, print_preset_styles
- Mam:  mamplot
- Ultra (lazy): mam_bode_plot, iplot, register_sci_plotly, register_sci_notebook, register_all
- Aliases: mam -> ysy_data_analysis_helper.ysy_mamplot
           ultra -> ysy_data_analysis_helper.YsyPlotHelperUltra
"""
from __future__ import annotations
import importlib as _importlib
from ._version import __version__
from .ysy_plot_helper import plot, temp_style, print_preset_styles

__all__ = [
    "__version__",
    "plot", "temp_style", "print_preset_styles",
    "mamplot",
    "mam_bode_plot", "iplot",
    "register_sci_plotly", "register_sci_notebook", "register_all",
    "mam", "ultra",
]

def __getattr__(name: str):
    if name == "mam":
        return _importlib.import_module("ysy_data_analysis_helper.ysy_mamplot")
    if name == "ultra":
        return _importlib.import_module("ysy_data_analysis_helper.YsyPlotHelperUltra")
    mapping = {
        "mamplot": ("ysy_data_analysis_helper.ysy_mamplot", "mamplot"),
        "mam_bode_plot": ("ysy_data_analysis_helper.YsyPlotHelperUltra.mam_bode_plot", "mam_bode_plot"),
        "iplot": ("ysy_data_analysis_helper.YsyPlotHelperUltra.ysy_iplot_helper", "iplot"),
        "register_sci_plotly": ("ysy_data_analysis_helper.YsyPlotHelperUltra.ysy_iplot_helper", "register_sci_plotly"),
        "register_sci_notebook": ("ysy_data_analysis_helper.YsyPlotHelperUltra.ysy_iplot_helper", "register_sci_notebook"),
        "register_all": ("ysy_data_analysis_helper.YsyPlotHelperUltra.ysy_iplot_helper", "register_all"),
    }
    if name in mapping:
        mod, attr = mapping[name]
        return getattr(_importlib.import_module(mod), attr)
    raise AttributeError(f"{__name__!r} has no attribute {name!r}")

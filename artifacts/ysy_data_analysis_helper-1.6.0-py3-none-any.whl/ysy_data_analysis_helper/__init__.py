"""
ysy_data_analysis_helper
Tiny, pragmatic helpers for data analysis.

Public API
----------
- plot(x, y, ...): quick line/scatter plotting with sane defaults.
- temp_style(style_keys: list[str], extra_style: str | None): temporary .mplstyle composition.
- print_preset_styles(): list available layout/color presets.

Notes
-----
- This package intentionally keeps plotting *style* choices minimal and unobtrusive.
- Version is sourced from `ysy_plot_helper.__version__` (single source of truth).
"""

# Single source of truth for version (defined in ysy_plot_helper.py)
from .ysy_plot_helper import __version__

# Re-export the primary APIs for convenience.
# (This does not change any of your plotting style logic or defaults.)
from .ysy_plot_helper import plot, temp_style, print_preset_styles

__author__ = "pifuyuini"
__email__ = "Contact via GitHub"

__all__ = [
    "__version__",
    "plot",
    "temp_style",
    "print_preset_styles",
]

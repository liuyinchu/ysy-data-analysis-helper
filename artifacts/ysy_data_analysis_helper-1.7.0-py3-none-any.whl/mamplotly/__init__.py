"""
mamplotly: convenience alias to ysy_data_analysis_helper.
"""
from __future__ import annotations
import ysy_data_analysis_helper as _pkg
from ysy_data_analysis_helper import __version__, plot, temp_style, print_preset_styles
__all__ = [
    "__version__",
    "plot", "temp_style", "print_preset_styles",
    "mamplot", "mam_bode_plot", "iplot",
    "register_sci_plotly", "register_sci_notebook", "register_all",
    "mam", "ultra",
]
def __getattr__(name: str):
    return getattr(_pkg, name)

# ysy_iplot_helper.py
# -*- coding: utf-8 -*-
"""
Interactive plotting helper for Plotly

Copyright (c) 2025 pifuyuini
Author: pifuyuini
Email: Contact via GitHub
Version: 1.0.0
Date: 2025-11-01

Description
-----------
This module integrates two *independent* capabilities under one roof:

1) `iplot(...)`: a pragmatic, standardized interactive plotting function
   (lines or markers) with fixed "plotly_white" styling. It mirrors the original
   behavior closely and only adds an optional `return_fig` to return the figure.

2) Plotly templates:
   - `register_sci_plotly(...)`    → registers a compact science-style template
   - `register_sci_notebook(...)`  → notebook-oriented override template
   - `register_all(...)`           → convenience to register both

**No coupling** is introduced between `iplot` and the templates. `iplot` always
uses the fixed `'plotly_white'` template and never auto-registers or switches to
the custom templates; the template functions exist merely as utilities within the
same module.

Usage
-----
# 1) Interactive plotting (always "plotly_white")
>>> import numpy as np
>>> from ysy_iplot_helper import iplot
>>> x = np.linspace(0, 2*np.pi, 200)
>>> y = np.sin(x)
>>> fig = iplot(x, y, legend_name='sin', plot_title='Sine', x_label='x', y_label='y')

# 2) Optional: register templates (independent of iplot)
>>> from ysy_iplot_helper import register_all
>>> register_all(set_default=False)  # does not affect iplot's fixed styling

Design Notes
-----------
- `iplot` preserves the original signature and logic with only requested changes:
  (a) multi-series detection uses `isinstance(y, (list, tuple))`,
  (b) fixed `'plotly_white'` template, no style loader involved,
  (c) no export functionality,
  (d) optional `return_fig=True` allows retrieving the Figure object.
- The template utilities are self-contained and never referenced by `iplot`.

License
-------
MIT
"""
from __future__ import annotations

from typing import Sequence, Tuple, Union, Optional
import copy

import plotly.graph_objects as go
import plotly.io as pio


__all__ = [
    "iplot",
    "register_sci_plotly",
    "register_sci_notebook",
    "register_all",
    "__version__",
]

__version__ = "1.0.0"


# =============================================================================
# 1) Interactive plotting (fixed plotly_white; no export; no style loader)
# =============================================================================
def iplot(
    x,
    y,
    legend_name,
    plot_title: str = '',
    x_label: str = 'X',
    y_label: str = 'Y',
    plot_type: str = 'curve',
    legend_title: str = '',
    return_fig: bool = True,
):
    """
    Plotly 实现的标准绘图函数，使用前请导入：`import plotly.graph_objects as go`。

    参数：
        x : array-like
        y : array-like 或多个 y 的元组/列表
        legend_name : str 或 str 列表
        plot_title : 图标题
        x_label : X轴标签
        y_label : Y轴标签
        plot_type : 'curve' 或 'scatter'
        legend_title : 图例标题
        return_fig : bool, default True
            如果为 True，则返回 `plotly.graph_objects.Figure`；否则返回 None。

    说明（与原实现保持一致的要点与仅有改动）
    ----------------------------------------
    - 模板固定为 'plotly_white'（不参与任何自定义样式加载/注册）。
    - 多曲线判定：仅依据 `isinstance(y, (list, tuple))`。
    - 不提供导出功能（无文件保存）。
    """
    fig = go.Figure()

    # 多条曲线情况（按要求：仅判断 y 是否为 list/tuple）
    if isinstance(y, (list, tuple)):
        for i, yi in enumerate(y):
            name = legend_name[i] if isinstance(legend_name, (list, tuple)) else f'Line {i}'
            mode = 'lines' if plot_type == 'curve' else 'markers'
            fig.add_trace(go.Scatter(
                x=x, y=yi, mode=mode, name=name,
                hovertemplate='x=%{x:.2f}<br>y=%{y:.2f}<extra></extra>'
            ))
    else:
        # 单条曲线
        mode = 'lines' if plot_type == 'curve' else 'markers'
        fig.add_trace(go.Scatter(
            x=x, y=y, mode=mode, name=legend_name,
            hovertemplate='x=%{x:.2f}<br>y=%{y:.2f}<extra></extra>'
        ))

    fig.update_layout(
        title=dict(text=plot_title, x=0.5, xanchor='center', font=dict(size=20)),
        xaxis=dict(title=dict(text=x_label, font=dict(size=16)), tickfont=dict(size=14)),
        yaxis=dict(title=dict(text=y_label, font=dict(size=16)), tickfont=dict(size=14)),
        legend=dict(title=dict(text=legend_title, font=dict(size=16)), font=dict(size=14)),
        template='plotly_white',   # 固定样式
        hovermode='closest'
    )

    fig.show()
    return fig if return_fig else None


# =============================================================================
# 2) Plotly templates (standalone; NO coupling to iplot)
# =============================================================================
def register_sci_plotly(*, set_default: bool = False, with_plotly_base: bool = True) -> str:
    """
    Register the 'sci_plotly' template (SciencePlots-style baseline).

    Intent
    ------
    - SciencePlots-like colorway.
    - Compact figure size (~3.5×2.625 in @ ~96 dpi → 336×252 px).
    - Inward ticks, mirrored top/right, thin grid lines.
    - Serif fonts; frameless legend; white background.

    Parameters
    ----------
    set_default : bool
        If True, set pio.templates.default to this theme.
    with_plotly_base : bool
        If True and set_default is True, default becomes "plotly+sci_plotly";
        otherwise "sci_plotly".

    Returns
    -------
    str
        The registered template name: "sci_plotly".

    Notes
    -----
    This utility is independent of `iplot()` and is not used implicitly.
    """
    tpl = go.layout.Template()

    # --- Color cycle (SciencePlots palette) ---
    tpl.layout.colorway = [
        "#0C5DA5", "#00B945", "#FF9500", "#FF2C00", "#845B97", "#474747", "#9e9e9e"
    ]

    # --- Figure size ---
    tpl.layout.width = 336
    tpl.layout.height = 252

    # --- Margins and title (left-leaning) ---
    tpl.layout.margin = dict(l=10, r=10, t=26, b=10)
    tpl.layout.title = dict(x=0.02, xanchor="left")

    # --- Background ---
    tpl.layout.paper_bgcolor = "white"
    tpl.layout.plot_bgcolor = "white"

    # --- Axes common styling ---
    axis_common = dict(
        showline=True,
        ticks="inside",
        ticklen=3,
        tickwidth=0.5,
        mirror="ticks",
        showgrid=True,
        gridwidth=0.5,
        gridcolor="#e0e0e0",
        zeroline=False,
        minor=dict(ticks="inside", ticklen=1.5, tickwidth=0.5, showgrid=False),
        automargin=True
    )
    tpl.layout.xaxis = go.layout.XAxis(**axis_common)
    tpl.layout.yaxis = go.layout.YAxis(**axis_common)

    # --- Legend and font ---
    tpl.layout.legend = dict(bgcolor="rgba(0,0,0,0)", bordercolor="rgba(0,0,0,0)", borderwidth=0)
    tpl.layout.font = dict(family="Times New Roman, Times, serif", size=12, color="#000")

    # --- Data defaults: marker-first, line width fallback ---
    tpl.data = go.layout.template.Data()
    tpl.data.scatter = [
        go.Scatter(mode="markers", marker=dict(symbol="circle", size=3), line=dict(width=1)),
        go.Scatter(mode="markers", marker=dict(symbol="square", size=3), line=dict(width=1)),
        go.Scatter(mode="markers", marker=dict(symbol="triangle-up", size=3), line=dict(width=1)),
        go.Scatter(mode="markers", marker=dict(symbol="triangle-down", size=3), line=dict(width=1)),
        go.Scatter(mode="markers", marker=dict(symbol="triangle-left", size=3), line=dict(width=1)),
        go.Scatter(mode="markers", marker=dict(symbol="triangle-right", size=3), line=dict(width=1)),
        go.Scatter(mode="markers", marker=dict(symbol="diamond", size=3), line=dict(width=1)),
    ]

    pio.templates["sci_plotly"] = tpl

    if set_default:
        pio.templates.default = ("plotly+sci_plotly") if with_plotly_base else "sci_plotly"

    return "sci_plotly"


def register_sci_notebook(*, set_default: bool = False, with_plotly_base: bool = True) -> str:
    """
    Register the 'sci_notebook' template as an incremental override of 'sci_plotly'
    for Jupyter/Notebook usage (bigger figure, larger fonts, centered title, thicker ticks, line plots).

    Changes relative to sci_plotly
    ------------------------------
    - Figure size: 8×6 in → ~768×576 px
    - Title: centered, larger font
    - Axes: longer/thicker ticks and grid; larger tick/label fonts
    - Legend fonts: larger
    - Data default: lines with width=2
    - Fonts: sans-serif for readability

    Parameters
    ----------
    set_default : bool
        If True, set pio.templates.default to this theme.
    with_plotly_base : bool
        If True and set_default is True, default becomes "plotly+sci_notebook";
        otherwise "sci_notebook".

    Returns
    -------
    str
        The registered template name: "sci_notebook".

    Notes
    -----
    This utility is independent of `iplot()` and is not used implicitly.
    """
    if "sci_plotly" not in pio.templates:
        register_sci_plotly(set_default=False)

    base = pio.templates["sci_plotly"]
    nb = go.layout.Template(layout=copy.deepcopy(base.layout),
                            data=copy.deepcopy(base.data))

    # --- Geometry ---
    nb.layout.width = 768
    nb.layout.height = 576
    nb.layout.margin = dict(l=60, r=20, t=60, b=50)

    # --- Title ---
    nb.layout.title = dict(x=0.5, xanchor="center", font=dict(size=16))

    # --- Axes overrides ---
    def _bump_axis(ax_obj):
        ax_obj.ticks = "inside"
        ax_obj.ticklen = 8
        ax_obj.tickwidth = 2
        ax_obj.tickfont = dict(size=22)
        ax_obj.title = dict(font=dict(size=22))
        ax_obj.gridwidth = 1.5
        ax_obj.minor = dict(ticks="inside", ticklen=6, tickwidth=2, showgrid=False)
        ax_obj.showline = True
        if ax_obj.mirror is None:
            ax_obj.mirror = "ticks"

    for nm in ("xaxis", "yaxis"):
        ax = getattr(nb.layout, nm)
        if isinstance(ax, dict):  # ensure object-typed axis
            ax = go.layout.XAxis(**ax) if nm == "xaxis" else go.layout.YAxis(**ax)
        _bump_axis(ax)
        setattr(nb.layout, nm, ax)

    # --- Legend fonts ---
    if not isinstance(nb.layout.legend, dict):
        nb.layout.legend = dict()
    nb.layout.legend["font"] = dict(size=22)
    nb.layout.legend["title"] = dict(font=dict(size=22))

    # --- Data default: lines ---
    nb.data = go.layout.template.Data()
    nb.data.scatter = [go.Scatter(mode="lines", line=dict(width=2))]

    # --- Notebook font ---
    nb.layout.font = dict(
        family="DejaVu Sans, Noto Sans, Arial, Helvetica, sans-serif",
        color="#000"
    )

    pio.templates["sci_notebook"] = nb

    if set_default:
        pio.templates.default = ("plotly+sci_notebook") if with_plotly_base else "sci_notebook"

    return "sci_notebook"


def register_all(*, set_default: bool = False) -> Tuple[str, str]:
    """
    Register both sci_plotly and sci_notebook; if `set_default=True`, default is
    set to "plotly+sci_notebook".

    Note: This does not affect `iplot`, which always uses "plotly_white".
    """
    name1 = register_sci_plotly(set_default=False)
    name2 = register_sci_notebook(set_default=set_default, with_plotly_base=True)
    return name1, name2

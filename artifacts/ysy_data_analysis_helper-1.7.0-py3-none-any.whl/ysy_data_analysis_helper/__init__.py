"""
ysy_data_analysis_helper
Tiny, pragmatic helpers for data analysis.

Top-level public API
--------------------
Core (Matplotlib):
- plot, temp_style, print_preset_styles

MamPlot (Matplotlib):
- mamplot

Ultra (NumPy/SciPy/Plotly; lazy-loaded):
- mam_bode_plot
- iplot
- register_sci_plotly, register_sci_notebook, register_all

Convenience:
- ultra   -> ysy_data_analysis_helper.YsyPlotHelperUltra  (module)
- mam     -> ysy_data_analysis_helper.ysy_mamplot         (module)
"""

from __future__ import annotations
import importlib as _importlib

# Package version: single source
from ._version import __version__

# Core, lightweight (no heavy deps)
from .ysy_plot_helper import plot, temp_style, print_preset_styles

__author__ = "pifuyuini"
__email__ = ""  # contact via GitHub

# Public names (lazy ones will be resolved in __getattr__)
__all__ = [
    "__version__",
    "plot", "temp_style", "print_preset_styles",
    # Lazy-resolved symbols:
    "mamplot",
    "mam_bode_plot",
    "iplot",
    "register_sci_plotly", "register_sci_notebook", "register_all",
    # Convenience module aliases:
    "ultra", "mam",
]


def __getattr__(name: str):
    """
    Lazy attribute resolver to avoid importing heavy deps unless needed.
    """
    # module shortcuts
    if name == "ultra":
        return _importlib.import_module("ysy_data_analysis_helper.YsyPlotHelperUltra")
    if name == "mam":
        return _importlib.import_module("ysy_data_analysis_helper.ysy_mamplot")

    # function-level mapping
    _map = {
        # Matplotlib mam-helpers
        "mamplot": ("ysy_data_analysis_helper.ysy_mamplot", "mamplot"),
        # Ultra: NumPy/SciPy/Plotly
        "mam_bode_plot": ("ysy_data_analysis_helper.YsyPlotHelperUltra.mam_bode_plot", "mam_bode_plot"),
        "iplot": ("ysy_data_analysis_helper.YsyPlotHelperUltra.ysy_iplot_helper", "iplot"),
        "register_sci_plotly": ("ysy_data_analysis_helper.YsyPlotHelperUltra.ysy_iplot_helper", "register_sci_plotly"),
        "register_sci_notebook": ("ysy_data_analysis_helper.YsyPlotHelperUltra.ysy_iplot_helper", "register_sci_notebook"),
        "register_all": ("ysy_data_analysis_helper.YsyPlotHelperUltra.ysy_iplot_helper", "register_all"),
    }
    if name in _map:
        mod, attr = _map[name]
        return getattr(_importlib.import_module(mod), attr)

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
from __future__ import annotations
import importlib as _importlib
__all__ = ["mam_bode_plot", "ysy_iplot_helper"]
def __getattr__(name: str):
    if name == "mam_bode_plot":
        return _importlib.import_module(__name__ + ".mam_bode_plot")
    if name == "ysy_iplot_helper":
        return _importlib.import_module(__name__ + ".ysy_iplot_helper")
    raise AttributeError(f"{__name__!r} has no attribute {name!r}")

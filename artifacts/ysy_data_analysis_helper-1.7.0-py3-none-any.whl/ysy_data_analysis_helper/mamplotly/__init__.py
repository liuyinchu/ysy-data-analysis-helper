"""
mamplotly: convenience alias for ysy_data_analysis_helper.

Usage:
    import mamplotly as mp

    mp.plot(...)
    mp.mamplot(...)
    mp.mam       # -> ysy_data_analysis_helper.ysy_mamplot (module)
    mp.ultra     # -> ysy_data_analysis_helper.YsyPlotHelperUltra (module)
"""

from __future__ import annotations
import importlib as _importlib
import ysy_data_analysis_helper as _pkg

# Re-export lightweight core
from ysy_data_analysis_helper import (
    __version__, plot, temp_style, print_preset_styles
)

__all__ = [
    "__version__",
    "plot", "temp_style", "print_preset_styles",
    # proxy to top-level lazy names
    "mamplot", "ultra", "mam", "mam_bode_plot", "iplot",
    "register_sci_plotly", "register_sci_notebook", "register_all",
]

def __getattr__(name: str):
    # delegate everything else to the main package (which is already lazy-capable)
    return getattr(_pkg, name)
# mam_bode_plot.py
# -*- coding: utf-8 -*-
"""
Bode plotting (Plotly) with optional SciPy system input and robust margins

Copyright (c) 2025 pifuyuini
Author: pifuyuini
Email: Contact via GitHub
Version: 1.0.0
Date: 2025-11-01

Description
-----------
This module provides a single entry point `mam_bode_plot(...)` to draw Bode
magnitude/phase plots using Plotly. It supports two input modes:

1) SciPy system mode:
   Pass a SciPy `scipy.signal` continuous-time LTI object (e.g., `lti`,
   `TransferFunction`, `StateSpace`, `ZerosPolesGain`) via `system=...`.
   Internally, the function calls `scipy.signal.bode(system, w)` to obtain
   (w [rad/s], magnitude [dB], phase [deg]).
   If `w` is None, SciPy will choose a default frequency grid.

2) Precomputed arrays mode:
   Do not pass `system`. Instead, provide all three arrays: `w`, `mag`, `phase`
   where `w` is in rad/s (strictly positive), `mag` in dB, and `phase` in deg.

Additionally:
- Optional stability margins analysis/annotation (PM, GM), default enabled.
- Optional Plotly template passthrough.
- Returns a Plotly Figure when `return_fig=True`.
- A reserved export hook is provided but intentionally left blank.

Usage
-----
>>> import numpy as np
>>> from scipy import signal
>>> from mam_bode_plot import mam_bode_plot
>>> # Example 1: SciPy system
>>> num, den = [1.0], [1.0, 1.0, 1.0]
>>> sys = signal.TransferFunction(num, den)
>>> fig = mam_bode_plot(system=sys, analyze_margins=True, template="plotly_white")

>>> # Example 2: Precomputed arrays
>>> w = np.logspace(-2, 2, 500)
>>> w2, mag, phase = signal.bode(sys, w)   # mag[dB], phase[deg]
>>> fig = mam_bode_plot(w=w2, mag=mag, phase=phase, analyze_margins=False)

Notes
-----
- Arrays must be finite and `w` must be > 0. A small internal sort ensures
  increasing frequency order before interpolation.
- Margin detection uses sign-change bracketing and log-frequency interpolation
  for robustness near the crossover points.
- Template is a simple passthrough to Plotly (e.g., "plotly_white", or any
  registered template string). This module does not auto-register templates.

License
-------
MIT
"""
from __future__ import annotations

from typing import Optional, Tuple, Union

import numpy as np
from scipy import signal
import plotly.graph_objects as go
from plotly.subplots import make_subplots


__all__ = ["mam_bode_plot", "__version__"]
__version__ = "1.0.0"


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _ensure_ascending(w: np.ndarray, *ys: np.ndarray) -> Tuple[np.ndarray, ...]:
    """Ensure frequency is strictly ascending; sort y-arrays accordingly."""
    order = np.argsort(w)
    w_sorted = w[order]
    out = [w_sorted]
    for y in ys:
        out.append(y[order])
    return tuple(out)  # type: ignore[return-value]


def _compute_margins(w: np.ndarray, mag_db: np.ndarray, phase_deg: np.ndarray) -> Tuple[float, float, float, float]:
    """
    Robust PM/GM estimation by sign-change bracketing + log-frequency interpolation.

    Returns
    -------
    gm_db, pm, gm_freq, pm_freq
    (NaN values are returned if a margin cannot be determined.)
    """
    gm_db = np.nan
    pm = np.nan
    gm_freq = np.nan
    pm_freq = np.nan

    try:
        # Gain crossover: |G(jw)| = 1 → mag = 0 dB
        # Detect sign changes of mag around 0 dB
        idxs = np.where(np.diff(np.sign(mag_db)) != 0)[0]
        if idxs.size > 0:
            i = int(idxs[0])
            log_w = np.log10(w)
            # interpolate log10(w) at mag==0
            log_pm_freq = np.interp(0.0, [mag_db[i + 1], mag_db[i]], [log_w[i + 1], log_w[i]])
            pm_freq = 10.0 ** log_pm_freq
            # phase at pm_freq
            phase_at_pm = np.interp(log_pm_freq, log_w, phase_deg)
            pm = phase_at_pm + 180.0  # PM = phase - (-180)
        # Phase crossover: phase = -180 deg
        idxs = np.where(np.diff(np.sign(phase_deg + 180.0)) != 0)[0]
        if idxs.size > 0:
            i = int(idxs[0])
            log_w = np.log10(w)
            log_gm_freq = np.interp(-180.0, [phase_deg[i + 1], phase_deg[i]], [log_w[i + 1], log_w[i]])
            gm_freq = 10.0 ** log_gm_freq
            # magnitude (dB) at gm_freq
            mag_at_gm = np.interp(log_gm_freq, log_w, mag_db)
            gm_db = -mag_at_gm  # GM = 0 - mag(dB)
    except Exception:
        # Return NaNs on failure by design
        pass

    return gm_db, pm, gm_freq, pm_freq


def _export_figure(fig: go.Figure, export) -> None:
    """
    Reserved hook for export (e.g., to static images or HTML).
    Intentionally left blank for future implementations.
    """
    _ = (fig, export)
    return


def _format_margin(v: float, unit: str) -> str:
    if np.isnan(v):
        return "N/A"
    if unit == "dB":
        return f"{v:.2f} dB"
    if unit == "deg":
        return f"{v:.2f} deg"
    if unit == "rad/s":
        return f"{v:.2f} rad/s"
    return f"{v:.2f}"


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def mam_bode_plot(
    *,
    system: Optional[Union[signal.lti, signal.TransferFunction, signal.ZerosPolesGain, signal.StateSpace]] = None,
    w: Optional[np.ndarray] = None,
    mag: Optional[np.ndarray] = None,
    phase: Optional[np.ndarray] = None,
    analyze_margins: bool = True,
    template: Optional[str] = "plotly_white",
    show: bool = True,
    return_fig: bool = True,
    export: Optional[object] = None,
    title: Optional[str] = None,
) -> Optional[go.Figure]:
    """
    Draw a Bode plot (magnitude/phase) with optional PM/GM analysis/annotations.

    Input modes
    -----------
    1) SciPy system mode:
       - Provide `system` (e.g., `signal.TransferFunction(...)`).
       - `w` can be an optional frequency array in rad/s; if None, SciPy will choose.
       - `mag` and `phase` must be None.
    2) Precomputed arrays mode:
       - Do not pass `system`.
       - Provide all three arrays: `w` (rad/s), `mag` (dB), `phase` (deg).

    Parameters
    ----------
    system : scipy.signal LTI object or None
        Continuous-time LTI system (lti/TransferFunction/ZPK/StateSpace).
    w : ndarray or None
        Frequencies in rad/s. If using system mode and `w` is None, SciPy selects a default.
    mag : ndarray or None
        Magnitude in dB (arrays mode only).
    phase : ndarray or None
        Phase in degrees (arrays mode only).
    analyze_margins : bool, default True
        If True, compute and annotate PM/GM.
    template : str or None, default "plotly_white"
        Plotly template name passed to `fig.update_layout(template=...)`.
    show : bool, default True
        If True, call `fig.show()` at the end.
    return_fig : bool, default True
        If True, return the constructed Plotly Figure; otherwise return None.
    export : object, default None
        Reserved export options; currently unused.
    title : str or None
        Title prefix. If None, a default "Bode Plot" is used. GM/PM summaries are appended
        when `analyze_margins` is True.

    Returns
    -------
    go.Figure or None
        Figure instance if `return_fig` is True, else None.

    Notes
    -----
    - Arrays are internally sorted by frequency to ensure ascending order
      before interpolation for margins.
    - `analyze_margins=False` skips both computation and visual annotations.
    """
    # -----------------------------
    # Input validation / data fetch
    # -----------------------------
    if system is not None:
        # System mode: `mag` and `phase` must not be provided
        if (mag is not None) or (phase is not None):
            raise ValueError("When `system` is provided, do not pass `mag` or `phase`.")
        # Compute bode via SciPy (mag[dB], phase[deg])
        w_out, mag_out, phase_out = signal.bode(system, w)  # type: ignore[arg-type]
    else:
        # Arrays mode: require all three
        if (w is None) or (mag is None) or (phase is None):
            raise ValueError("Provide `w`, `mag`, and `phase` when `system` is not given.")
        w_out, mag_out, phase_out = np.asarray(w), np.asarray(mag), np.asarray(phase)

    # Ensure numeric arrays and valid frequencies
    w_out = np.asarray(w_out, dtype=float)
    mag_out = np.asarray(mag_out, dtype=float)
    phase_out = np.asarray(phase_out, dtype=float)

    if np.any(~np.isfinite(w_out)) or np.any(~np.isfinite(mag_out)) or np.any(~np.isfinite(phase_out)):
        raise ValueError("Non-finite values detected in w/mag/phase.")
    if np.any(w_out <= 0):
        raise ValueError("All frequencies `w` must be positive (rad/s).")

    # Sort by ascending frequency for consistent interpolation
    w_out, mag_out, phase_out = _ensure_ascending(w_out, mag_out, phase_out)  # type: ignore[assignment]

    # -----------------------------
    # Optional margin computation
    # -----------------------------
    gm_db, pm, gm_freq, pm_freq = (np.nan, np.nan, np.nan, np.nan)
    if analyze_margins:
        gm_db, pm, gm_freq, pm_freq = _compute_margins(w_out, mag_out, phase_out)

    # -----------------------------
    # Plotly figure
    # -----------------------------
    fig = make_subplots(
        rows=2, cols=1, shared_xaxes=True, vertical_spacing=0.0,
        subplot_titles=("", "")
    )

    # Magnitude (dB)
    fig.add_trace(
        go.Scatter(x=w_out, y=mag_out, mode="lines", name="Gain", line=dict(color="blue")),
        row=1, col=1
    )
    # 0 dB line
    fig.add_shape(
        type="line", x0=w_out[0], y0=0, x1=w_out[-1], y1=0,
        line=dict(color="black", width=2, dash="dash"),
        row=1, col=1
    )

    # Phase (deg)
    fig.add_trace(
        go.Scatter(x=w_out, y=phase_out, mode="lines", name="Phase", line=dict(color="red")),
        row=2, col=1
    )
    # -180 deg line
    fig.add_shape(
        type="line", x0=w_out[0], y0=-180, x1=w_out[-1], y1=-180,
        line=dict(color="black", width=2, dash="dash"),
        row=2, col=1
    )

    # -----------------------------
    # Optional PM/GM annotations
    # -----------------------------
    if analyze_margins:
        # PM
        if np.isfinite(pm) and np.isfinite(pm_freq):
            # Vertical lines at pm_freq
            fig.add_shape(
                type="line",
                x0=pm_freq, y0=float(np.min(mag_out)), x1=pm_freq, y1=float(np.max(mag_out)),
                line=dict(color="black", width=2, dash="dash"),
                row=1, col=1
            )
            fig.add_shape(
                type="line",
                x0=pm_freq, y0=float(np.min(phase_out)), x1=pm_freq, y1=float(np.max(phase_out)),
                line=dict(color="black", width=2, dash="dash"),
                row=2, col=1
            )
            # Red segment from -180 to actual phase at pm_freq
            log_pm = np.log10(pm_freq)
            phase_at_pm = float(np.interp(log_pm, np.log10(w_out), phase_out))
            fig.add_shape(
                type="line",
                x0=pm_freq, y0=-180, x1=pm_freq, y1=phase_at_pm,
                line=dict(color="red", width=3),
                row=2, col=1
            )

        # GM
        if np.isfinite(gm_db) and np.isfinite(gm_freq):
            mag_at_gm = -gm_db  # recall: gm_db = 0 - mag_at_gm
            fig.add_shape(
                type="line",
                x0=gm_freq, y0=float(np.min(mag_out)), x1=gm_freq, y1=float(np.max(mag_out)),
                line=dict(color="black", width=2, dash="dash"),
                row=1, col=1
            )
            fig.add_shape(
                type="line",
                x0=gm_freq, y0=float(mag_at_gm), x1=gm_freq, y1=0.0,
                line=dict(color="blue", width=3),
                row=1, col=1
            )
            fig.add_shape(
                type="line",
                x0=gm_freq, y0=float(np.min(phase_out)), x1=gm_freq, y1=float(np.max(phase_out)),
                line=dict(color="black", width=2, dash="dash"),
                row=2, col=1
            )

    # -----------------------------
    # Axes & layout
    # -----------------------------
    fig.update_xaxes(type="log", title_text="", row=1, col=1)
    fig.update_xaxes(type="log", title_text="Frequency (rad/s)", row=2, col=1)

    fig.update_yaxes(title_text="Magnitude (dB)", row=1, col=1)
    fig.update_yaxes(title_text="Phase (deg)", row=2, col=1)

    if title is None:
        if analyze_margins:
            gm_str = _format_margin(gm_db, "dB")
            pm_str = _format_margin(pm, "deg")
            gmf_str = _format_margin(gm_freq, "rad/s")
            pmf_str = _format_margin(pm_freq, "rad/s")
            title_text = f"Bode Plot | GM = {gm_str} (@ {gmf_str}), PM = {pm_str} (@ {pmf_str})"
        else:
            title_text = "Bode Plot"
    else:
        title_text = title

    fig.update_layout(
        title_text=title_text,
        showlegend=True,
        hovermode="x unified",
        template=template or None,
        margin=dict(t=60, l=60, r=20, b=50),
    )

    # -----------------------------
    # Reserved export (no-op)
    # -----------------------------
    _export_figure(fig, export)

    # -----------------------------
    # Show / return
    # -----------------------------
    if show:
        fig.show()

    return fig if return_fig else None

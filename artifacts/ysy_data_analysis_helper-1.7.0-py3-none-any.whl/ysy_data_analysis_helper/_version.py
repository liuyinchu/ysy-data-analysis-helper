# Single source of truth for the package version
__version__ = "1.7.0"